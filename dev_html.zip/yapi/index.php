<!DOCTYPE html>
<html>
<head>
    <?php
        $page_name = "YAPI";
        include "{$_SERVER['DOCUMENT_ROOT']}/shared/_title.php";
        include "{$_SERVER['DOCUMENT_ROOT']}/shared/_imports.html";
    ?>
</head>
<body>
    <header>
        <?php include "{$_SERVER['DOCUMENT_ROOT']}/shared/_nav.html"; ?>
        <h1>Welcome to YAPI!</p>
    </header>
    <section>
        <h2>Who are we?</h2>
        <p>YAPI was founded in 1984 as...</p>
    </section>
    <footer>
    </footer>
</body>
</html>