<!DOCTYPE html>
<html>
<head>
    <?php
        $page_name = "Bishop";
        include "{$_SERVER['DOCUMENT_ROOT']}/shared/_title.php";
        include "{$_SERVER['DOCUMENT_ROOT']}/shared/_imports.html";
    ?>
</head>
<body>
    <header>
        <?php include "{$_SERVER['DOCUMENT_ROOT']}/shared/_nav.html"; ?>
        <h1>Meet our Bishop</p>
    </header>
    <main>
        <section>
        </section>
    </main>
    <footer>
    </footer>
</body>
</html>