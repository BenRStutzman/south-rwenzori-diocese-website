<!DOCTYPE html>
<html>
<head>
    <?php
        $page_name = "Bishop";
        include "{$_SERVER['DOCUMENT_ROOT']}/shared/_title.php";
        include "{$_SERVER['DOCUMENT_ROOT']}/shared/_imports.html";
    ?>
</head>
<body>
    <?php include "{$_SERVER['DOCUMENT_ROOT']}/shared/_header.html"; ?>
    <main>
        <h1>Meet our Bishop</h1>
        <section>
        </section>
    </main>
</body>
</html>