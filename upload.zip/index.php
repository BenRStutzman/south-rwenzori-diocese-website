<!DOCTYPE html>
<html>
<head>
    <?php
        $page_name = "Home";
        include "{$_SERVER['DOCUMENT_ROOT']}/shared/_title.php";
    ?>
</head>
<body>
    <header>
        <?php include "{$_SERVER['DOCUMENT_ROOT']}/shared/_nav.html"; ?>
        <h1>Welcome to South Rwenzori Diocese!</p>
    </header>
    <section>
        <h2>Who are we?</h2>
        <p>South Rwenzori Diocese was founded in 1984 as...</p>
    </section>
    <footer>
    </footer>
</body>
</html>