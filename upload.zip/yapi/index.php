<!DOCTYPE html>
<html>
<head>
    <?php
        $page_name = "YAPI";
        include "{$_SERVER['DOCUMENT_ROOT']}/shared/_title.php";
        include "{$_SERVER['DOCUMENT_ROOT']}/shared/_imports.html";
    ?>
</head>
<body>
    <header>
        <?php include "{$_SERVER['DOCUMENT_ROOT']}/shared/_nav.html"; ?>
        <h1>Young and Powerful Initiative</p>
    </header>
    <main>
        <section>
            <h2>Who are we?</h2>
            <p>YAPI was founded in 1984 as...</p>
        </section>
    </main>
    <footer>
    </footer>
</body>
</html>