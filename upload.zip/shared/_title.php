<title>
    <?php
        $site_name = "South Rwenzori Diocese";
        echo is_null($page_name) ? $site_name : "$site_name - $page_name";
    ?>
</title>