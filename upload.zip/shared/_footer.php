<footer>
    &copy; <?php echo date("Y"); ?> South Rwenzori Diocese
</footer>