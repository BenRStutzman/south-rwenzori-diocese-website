<!DOCTYPE html>
<html>
<head>
    <?php
        $page_name = "Estate";
        include "{$_SERVER['DOCUMENT_ROOT']}/shared/_title.php";
        include "{$_SERVER['DOCUMENT_ROOT']}/shared/_imports.php";
    ?>
</head>
<body>
    <?php include "{$_SERVER['DOCUMENT_ROOT']}/shared/_header.php"; ?>
    <main>
        <h1>Directorate of Estate</h1>
        <section>
        </section>
    </main>
    <?php include "{$_SERVER['DOCUMENT_ROOT']}/shared/_footer.php"; ?>
</body>
</html>